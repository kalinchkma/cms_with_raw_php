<?php

echo password_hash("10211", PASSWORD_BCRYPT, array("cost" => 10));