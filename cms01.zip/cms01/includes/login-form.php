  

       <form action="includes/login.php" method="post">
           <h4>Login</h4>
           <div class="form-group">
               <input name="username" type="text" class="form-control" placeholder="Enter user name">

           </div>
           <div class="input-group">
               <input name="password" type="password" class="form-control" placeholder="password">
               <span class="input-group-btn">
                   <button class="btn btn-primary" name="login" type="submit">
                       Login
                   </button>
               </span>
           </div>
       </form>
       <!-- /.input-group -->

           